<div class="col-md-4 col-sm-6">
                    <div class="pricingTable">
                        <div class="pricingTable-header">
                            <span class="heading">
                                <h3>{{data[0][6]}}</h3>
                            </span>
                           
                        </div>

                        <div class="pricingContent">
                            <i class="fa fa-adjust"></i>
                            <ul>
                                <li>Name: {{data[0][2]}}</li>
                                <li>Mobile No: {{data[0][3]}}</li>
                                <li>E-mail ID: {{data[0][4]}}</li>
                                <li>City: {{data[0][5]}}</li>
                            </ul>
                        </div><!-- /  CONTENT BOX-->

                        <div class="pricingTable-sign-up">
                            <a href="/view_dist" class="hover-btn-new"><span>View All</span></a>
                        </div><!-- BUTTON BOX-->
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="pricingTable pink">
                        <div class="pricingTable-header">
                            <span class="heading">
                                <h3>{{data[1][6]}}</h3>
                            </span>
                          
                        </div>

                        <div class="pricingContent">
                            <i class="fa fa-briefcase"></i>
                            <ul>
                                <li>Name: {{data[1][2]}}</li>
                                <li>Mobile No: {{data[1][3]}}</li>
                                <li>E-mail ID: {{data[1][4]}}</li>
                                <li>City: {{data[1][5]}}</li>
                            </ul>
                        </div><!-- /  CONTENT BOX-->

                        <div class="pricingTable-sign-up">
                            <a href="/view_dist" class="hover-btn-new"><span>View All</span></a>
                        </div><!-- BUTTON BOX-->
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="pricingTable orange">
                        <div class="pricingTable-header">
                            <span class="heading">
                                <h3>{{data[2][6]}}</h3>
                            </span>
                            
                        </div>

                        <div class="pricingContent">
                            <i class="fa fa-cube"></i>
                            <ul>
                                <li>Name: {{data[2][2]}}</li>
                                <li>Mobile No: {{data[2][3]}}</li>
                                <li>E-mail ID: {{data[2][4]}}</li>
                                <li>City: {{data[2][5]}}</li>
                            </ul>
                        </div><!-- /  CONTENT BOX-->

                        <div class="pricingTable-sign-up">
                            <a href="/view_dist" class="hover-btn-new"><span>View All</span></a>
                        </div><!-- BUTTON BOX-->
                    </div>
                </div>